const toggle = document.getElementById('darkmode-toggle');
const body = document.body;
const title = document.getElementById('title');

const saved = localStorage.getItem('theme'); 
if (saved === 'dark') {
  body.classList.add('dark');
  toggle.checked = true;
  title.textContent = 'Modo Noche 🌙';
} else {
  body.classList.remove('dark');
  toggle.checked = false;
  title.textContent = 'Modo Día ☀️';
}


toggle.addEventListener('change', (e) => {
  if (e.target.checked) {
    body.classList.add('dark');
    title.textContent = 'Modo Noche 🌙';
    localStorage.setItem('theme', 'dark');
  } else {
    body.classList.remove('dark');
    title.textContent = 'Modo Día ☀️';
    localStorage.removeItem('theme');
  }
});
